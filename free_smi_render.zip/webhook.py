"""Telegram webhook for Render; no external Python packages required."""
import os, json, hmac, logging, threading, re
from http.server import BaseHTTPRequestHandler, HTTPServer
import bot

SECRET = os.environ.get('WEBHOOK_SECRET', '')
BASE = os.environ.get('RENDER_EXTERNAL_URL', '').rstrip('/')
if not bot.TOKEN or not BASE or not re.fullmatch(r'[A-Za-z0-9_-]{16,256}', SECRET):
    raise SystemExit('Set BOT_TOKEN and WEBHOOK_SECRET (16+ letters, digits, underscores or hyphens). Render supplies RENDER_EXTERNAL_URL.')

class Handler(BaseHTTPRequestHandler):
    def respond(self, code, body=b''):
        self.send_response(code); self.send_header('Content-Type','text/plain'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        self.respond(200, b'OK') if self.path=='/' else self.respond(404)
    def do_POST(self):
        if self.path != '/telegram': return self.respond(404)
        if not hmac.compare_digest(self.headers.get('X-Telegram-Bot-Api-Secret-Token',''),SECRET): return self.respond(403)
        try:
            length = int(self.headers.get('Content-Length','0'))
            if not 0 < length <= 2_000_000: return self.respond(400)
            update=json.loads(self.rfile.read(length))
            if not isinstance(update,dict): return self.respond(400)
        except (ValueError, TypeError): return self.respond(400)
        try: bot.dispatch(update)
        except Exception as e:
            logging.warning('Update failed: %s',type(e).__name__)
        self.respond(200,b'OK')
    def log_message(self, fmt, *args): pass

def register():
    import time
    while True:
        try:
            bot.api('setWebhook',url=BASE+'/telegram',secret_token=SECRET,allowed_updates=['message','business_connection','business_message'],max_connections=1)
            logging.info('Webhook registered.'); return
        except Exception as e:
            logging.warning('Webhook setup failed: %s',type(e).__name__); time.sleep(10)

if __name__=='__main__':
    server=HTTPServer(('0.0.0.0',int(os.getenv('PORT','10000'))),Handler)
    threading.Thread(target=register,daemon=True).start()
    server.serve_forever()
