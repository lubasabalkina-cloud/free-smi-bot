"""FREE SMI — single-owner Telegram bot using official Bot API only."""
import os, json, time, urllib.request, urllib.error, logging, re
from pathlib import Path

TOKEN = os.getenv('BOT_TOKEN', '')
OWNER = int(os.getenv('OWNER_ID', '0'))
STATE = Path(os.getenv('STATE_FILE', 'state.json'))
DEFAULT = {'emoji': True, 'pack': 'classic', 'packs': {}, 'away': False, 'away_text': 'Сейчас не могу ответить. Напишу позже!', 'quick': {'привет': 'Привет! 👋', 'спасибо': 'Спасибо! ❤️'}, 'saved': [], 'replies': {}}
STYLES = {'classic': {':)': '😊', ':D': '😄', ';)': '😉', '<3': '❤️', '😂': '🤣'}, 'bright': {':)': '😎', ':D': '🤩', ';)': '😜', '<3': '💖', '😂': '😹'}}
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
class APIError(Exception): pass

def api(method, **params):
    req = urllib.request.Request('https://api.telegram.org/bot' + TOKEN + '/' + method, data=json.dumps(params).encode(), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=45) as res: data = json.load(res)
    except urllib.error.HTTPError as e:
        try: data = json.load(e)
        except Exception: data = {'description': 'HTTP '+str(e.code)}
        raise APIError(data.get('description', 'Ошибка Telegram')) from None
    if not data.get('ok'): raise APIError(data.get('description', 'Ошибка Telegram'))
    return data['result']

def load():
    if STATE.exists():
        with STATE.open(encoding='utf-8') as f: return {**DEFAULT, **json.load(f)}
    return json.loads(json.dumps(DEFAULT))

def persist():
    tmp = STATE.with_suffix('.tmp')
    fd = os.open(tmp, os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as f: json.dump(S, f, ensure_ascii=False)
    os.replace(tmp, STATE)

S = load()
CONNECTIONS = {}
WARNED = set()

def send(chat, text, **kw):
    return api('sendMessage', chat_id=chat, text=text, **kw)

def edit(m, text, entities=None):
    args = {'chat_id': m['chat']['id'], 'message_id': m['message_id'], 'business_connection_id': m['business_connection_id'], 'text': text}
    if entities is not None: args['entities'] = entities
    return api('editMessageText', **args)

def u16(s): return len(s.encode('utf-16-le'))//2

def emoji_transform(text, style, custom):
    # One pass; offsets are UTF-16, as Telegram requires.
    mapping = {**STYLES.get(style, {}), **{k: v['emoji'] for k,v in custom.items()}}
    if not mapping: return text, []
    regex = re.compile('|'.join(re.escape(k) for k in sorted(mapping, key=len, reverse=True)))
    out, entities, pos, offset = [], [], 0, 0
    for match in regex.finditer(text):
        before = text[pos:match.start()]; out.append(before); offset += u16(before)
        key = match.group(); val = mapping[key]; out.append(val)
        if key in custom:
            entities.append({'type':'custom_emoji','offset':offset,'length':u16(val),'custom_emoji_id':custom[key]['id']})
        offset += u16(val); pos = match.end()
    out.append(text[pos:]); return ''.join(out), entities

def custom_pack(): return S['packs'].get(S['pack'], {})

HELP = '''FREE SMI • настройки
/id — мой Telegram ID
/status — состояние
/emoji on|off — автозамена
/pack classic|bright — стиль; /pack ИМЯ — свой набор
/addpack ИМЯ ССЫЛКА_ИЛИ_ИМЯ_НАБОРА — загрузить набор эмодзи
/away on|off — автоответчик
/awaytext ТЕКСТ — текст автоответа
/quick ИМЯ ТЕКСТ — быстрая фраза; .q ИМЯ в личной переписке
/save ТЕКСТ — сохранить свою заметку
/saved — заметки; /clear — удалить все заметки
/repeat ТЕКСТ — повторить один раз здесь
В супергруппе: ответь на сообщение командой .мут 10 или .размут (нужны права администратора).
Личные чаты: подключи бота к профилю в настройках Telegram. Автоответ действует не чаще раза в час на чат. Автоэмодзи — только для твоих исходящих сообщений.''' 

def owner_command(m):
    chat = m['chat']['id']; text = m.get('text',''); parts = text.split(maxsplit=1); cmd = parts[0].split('@')[0].lower() if parts else ''; arg = parts[1].strip() if len(parts)>1 else ''
    if cmd == '/id': send(chat, str(m['from']['id'])); return
    if m['from']['id'] != OWNER: return
    if cmd in ('/start','/help'): send(chat, HELP)
    elif cmd == '/status': send(chat, f"Эмодзи: {S['emoji']}\nСтиль: {S['pack']}\nАвтоответ: {S['away']}\nНаборы: {', '.join(['classic','bright']+list(S['packs']))}\nЗаметок: {len(S['saved'])}")
    elif cmd in ('/emoji','/away'):
        if arg not in ('on','off'): send(chat, 'Используй on или off.'); return
        S[cmd[1:]] = arg=='on'; persist(); send(chat, 'Настройка сохранена.')
    elif cmd == '/pack':
        if arg not in STYLES and arg not in S['packs']: send(chat, 'Нет такого набора. /status покажет доступные.'); return
        S['pack']=arg; persist(); send(chat,'Стиль выбран.')
    elif cmd == '/addpack':
        a=arg.split(maxsplit=1)
        if len(a)!=2 or not re.fullmatch(r'[\w-]{1,32}', a[0]) or a[0] in STYLES: send(chat, 'Пример: /addpack MyPack https://t.me/addemoji/ИмяНабора'); return
        name=a[1].rstrip('/').split('/')[-1].split('?')[0]
        if not re.fullmatch(r'[A-Za-z0-9_]{1,128}',name): send(chat,'Неверное имя набора.'); return
        st=api('getStickerSet',name=name)
        if st.get('sticker_type')!='custom_emoji': send(chat,'Нужен набор именно эмодзи, не обычных стикеров.'); return
        mapping={}
        for s in st.get('stickers',[]):
            if s.get('custom_emoji_id') and s.get('emoji') and (s.get('is_animated') or s.get('is_video')): mapping.setdefault(s['emoji'], {'emoji':s['emoji'],'id':s['custom_emoji_id']})
        if not mapping: send(chat,'В наборе нет подходящих анимированных эмодзи.'); return
        S['packs'][a[0]]=mapping; S['pack']=a[0]; persist(); send(chat,f'Набор сохранён: {len(mapping)} эмодзи. Telegram может ограничить их использование.')
    elif cmd == '/awaytext' and arg: S['away_text']=arg[:1000]; persist(); send(chat,'Автоответ обновлён.')
    elif cmd == '/quick':
        a=arg.split(maxsplit=1)
        if len(a)!=2: send(chat,'Пример: /quick привет Привет! 👋'); return
        S['quick'][a[0]]=a[1][:1000]; persist(); send(chat,'Фраза сохранена.')
    elif cmd == '/save' and arg:
        S['saved']=(S['saved']+[arg[:2000]])[-50:]; persist(); send(chat,'Заметка сохранена.')
    elif cmd == '/saved': send(chat, '\n\n'.join(f'{i+1}. {v}' for i,v in enumerate(S['saved']))[-3800:] or 'Нет заметок.')
    elif cmd == '/clear': S['saved']=[]; persist(); send(chat,'Заметки удалены.')
    elif cmd == '/repeat' and arg: send(chat,arg[:2000])
    else: send(chat, 'Команды: /help')

def business(m):
    cid=m['business_connection_id']; c=CONNECTIONS.get(cid)
    if c is None: c=api('getBusinessConnection',business_connection_id=cid); CONNECTIONS[cid]=c
    if not c.get('is_enabled') or c.get('user',{}).get('id')!=OWNER: return
    if not c.get('rights',{}).get('can_reply'): return
    sender=m.get('from',{}); chat=m['chat']['id']; text=m.get('text','')
    if sender.get('id')==OWNER:
        if m.get('sender_business_bot') or not text: return
        if text.startswith('.q '):
            phrase=S['quick'].get(text[3:].strip());
            if phrase: edit(m,phrase)
            return
        # Do not touch formatting, links, existing custom emoji or other entities.
        if not S['emoji'] or m.get('entities') or text.startswith(('/', '.')) and not text.startswith((':)', ':D')): return
        new, entities=emoji_transform(text,S['pack'],custom_pack())
        if new==text and not entities: return
        try: edit(m,new,entities)
        except APIError:
            if entities:
                fallback,_=emoji_transform(text,'classic',{})
                if fallback!=text: edit(m,fallback)
                if cid not in WARNED:
                    WARNED.add(cid)
                    try: send(OWNER,'Telegram не разрешил премиум-эмодзи в этой переписке. Обычные эмодзи остаются доступны.')
                    except APIError: pass
            else: raise
    elif S['away'] and not sender.get('is_bot') and sender.get('id') and text:
        key=str(chat); now=time.time()
        if now-S['replies'].get(key,0)<3600: return
        send(chat,S['away_text'],business_connection_id=cid); S['replies'][key]=now
        S['replies']={k:v for k,v in S['replies'].items() if now-v<86400}; persist()

def group(m):
    text=m.get('text',''); parts=text.split(); cmd=parts[0].split('@')[0].lower() if parts else ''
    if cmd not in ('.мут','.размут','/mute','/unmute') or m.get('from',{}).get('id')!=OWNER: return
    chat=m['chat']['id']; target=m.get('reply_to_message',{}).get('from',{}).get('id')
    if m['chat']['type']!='supergroup' or not target or target==OWNER: send(chat,'Ответь на сообщение участника в супергруппе.'); return
    member=api('getChatMember',chat_id=chat,user_id=OWNER)
    if member['status']!='creator' and not (member['status']=='administrator' and member.get('can_restrict_members')): return
    if cmd in ('.мут','/mute'):
        try: minutes=int(parts[1]) if len(parts)>1 else 10
        except ValueError: send(chat,'Пример: .мут 10'); return
        minutes=max(1,min(minutes,1440)); perms={'can_send_messages':False,'can_send_audios':False,'can_send_documents':False,'can_send_photos':False,'can_send_videos':False,'can_send_video_notes':False,'can_send_voice_notes':False,'can_send_polls':False,'can_send_other_messages':False,'can_add_web_page_previews':False}
        api('restrictChatMember',chat_id=chat,user_id=target,permissions=perms,use_independent_chat_permissions=True,until_date=int(time.time())+minutes*60); send(chat,f'Мут на {minutes} мин.')
    else:
        perms=api('getChat',chat_id=chat).get('permissions',{});
        if not perms: send(chat,'Не удалось получить стандартные права группы.'); return
        api('restrictChatMember',chat_id=chat,user_id=target,permissions=perms,use_independent_chat_permissions=True); send(chat,'Мут снят.')

def dispatch(u):
    if 'business_connection' in u:
        c=u['business_connection']; CONNECTIONS[c['id']]=c
    elif 'business_message' in u: business(u['business_message'])
    elif 'message' in u:
        m=u['message']
        if not m.get('from'): return
        if m['chat']['type']=='private': owner_command(m)
        else: group(m)

def main():
    if not TOKEN: raise SystemExit('Укажи BOT_TOKEN в переменной окружения.')
    if not OWNER: print('Режим настройки: отправь боту /id, затем перезапусти с OWNER_ID. Остальные функции закрыты.')
    me=api('getMe'); print('Бот запущен: @'+me['username'],flush=True)
    api('deleteWebhook',drop_pending_updates=False); offset=None
    while True:
        try:
            p={'timeout':30,'allowed_updates':['message','business_connection','business_message']}
            if offset is not None: p['offset']=offset
            for u in api('getUpdates',**p):
                try: dispatch(u)
                except Exception as e:
                    logging.warning('Ошибка обработки: %s', type(e).__name__)
                    m=u.get('message',{}); sender=m.get('from',{})
                    if m.get('chat',{}).get('type')=='private' and sender.get('id')==OWNER:
                        try: send(OWNER,'Не удалось выполнить команду. Проверь параметры и разрешения Telegram.')
                        except Exception: pass
                offset=u['update_id']+1
        except (APIError,OSError,TimeoutError): logging.warning('Ошибка сети/API, повтор подключения'); time.sleep(3)

if __name__=='__main__': main()
