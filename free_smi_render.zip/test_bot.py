import unittest
from bot import emoji_transform, u16
class TestEmoji(unittest.TestCase):
    def test_basic(self): self.assertEqual(emoji_transform('Привет :)', 'classic', {}), ('Привет 😊', []))
    def test_utf16(self):
        t,e=emoji_transform('😎😂', 'custom', {'😂':{'emoji':'😂','id':'123'}})
        self.assertEqual(t,'😎😂'); self.assertEqual(e[0]['offset'],2); self.assertEqual(e[0]['length'],2)
    def test_empty(self): self.assertEqual(emoji_transform('текст','classic',{}),('текст',[]))
if __name__=='__main__': unittest.main()
